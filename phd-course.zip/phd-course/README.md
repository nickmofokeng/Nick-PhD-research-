# PhD Self-Paced Course — Setup & Use

A strictly gated, self-paced course system for the subject **"Application of Bioagents
in the Control of Pests in Vegetable Crops"**. Learn → get examined → get graded →
unlock the next topic. Built to run in **Claude Code** (Codespaces, desktop, or mobile).

## What this does
- Teaches each of the 9 curriculum topics as structured lessons, from YOUR uploaded sources.
- Sets a written exam per topic (short-answer + essay + MCQ).
- Grades your answers on the Bulgarian 6-point scale with detailed feedback.
- Unlocks the next topic ONLY when you score ≥ 4.50 (Good). Strict gating, no skipping.

## One-time setup
1. Copy the contents of this folder into your PhD repo (or use it as its own repo).
2. Create a `sources/` folder and add your materials. Suggested filenames (referenced in
   PROGRESS.md — rename there if you use different ones):
   - `sources/curriculum.docx`
   - `sources/schmidt-jeffris-2023.pdf`
   - `sources/overton-2023.pdf`
   - `sources/gullan-cranston.pdf`
3. Open the repo in Claude Code.

## The four commands (your weekly loop)
Claude Code reads the agent files in `.claude/agents/` automatically. To run each step,
just ask Claude Code in natural language — for example:

| Step | What you say to Claude Code | What happens |
|------|-----------------------------|--------------|
| Learn | "Use the **tutor** agent to teach my current topic" | Lessons written to `course/lessons/topic-N.md` |
| Exam  | "Use the **examiner** agent to set my exam" | Paper written to `course/exams/topic-N.md` |
| Answer | *(you type your answers)* | Save them in `course/answers/topic-N.md` |
| Grade | "Use the **grader** agent to grade my answers" | Report in `course/grades/`; next topic unlocks on a pass |

The agents always check `course/PROGRESS.md` first, so they know which topic you're on.

## Rules that keep it honest
- Topics unlock strictly in order (1 → 9).
- Pass = **4.50** on the 6-point scale. Only the grader can unlock, only on a real pass.
- The examiner never shows answers; the marking key is hidden from you in `exams/.keys/`.
- Every retake gets a fresh paper on the same syllabus.

## Adding more topics or subjects later
This system is reusable. To run a different subject, copy the folder, swap the files in
`sources/`, and rewrite the TOPIC LEDGER in `PROGRESS.md` with the new topics. The agents
don't need changing.

## Tip
Commit after each pass. Your `PROGRESS.md` grade log becomes a full record of your journey
through the course — useful evidence of preparation before the real exam on 1 September.
