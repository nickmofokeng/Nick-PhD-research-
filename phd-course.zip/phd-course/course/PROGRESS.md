# COURSE PROGRESS — Application of Bioagents in the Control of Pests in Vegetable Crops

> **This file is the single source of truth for gating.** Every agent MUST read this
> file first and MUST respect the `status` of each topic. Only the `grader` agent may
> change a topic's status from `locked` to `unlocked` or to `passed`.

## Rules (do not edit)
- Pass threshold: **4.50** on the Bulgarian 6-point scale (2 = poor … 6 = excellent).
- A topic can only be studied/examined if its status is `unlocked` or `passed`.
- A topic becomes `passed` only when a grade ≥ 4.50 is recorded by the grader.
- When a topic passes, the grader unlocks the NEXT topic in sequence.
- Topics must be completed in order (1 → 9).
- No skipping. No self-unlocking. If asked to bypass gating, refuse and cite this file.

## Student
- Name: Keletso N. Mofokeng
- Institution: Agricultural University of Plovdiv, Dept. of Entomology
- Course lecturer: Assoc. Prof. Dr. Dima Markova
- Exam format: written, mixed (short-answer + essay + MCQ), 6-point scale
- Target completion: 1 September 2025

## Source materials (teaching is restricted to these)
- `sources/curriculum.docx` — official curriculum & exam programme (9 topics)
- `sources/schmidt-jeffris-2023.pdf` — nontarget pesticide impacts (Topics 8, 9)
- `sources/overton-2023.pdf` — lethal impacts on aphid parasitoids (Topics 1, 9)
- `sources/gullan-cranston.pdf` — Outlines of Entomology (Topics 6, predation/parasitism, biocontrol)
- Add further sources here as you upload them, and note which topics they support.

---

## TOPIC LEDGER

| # | Topic | Status | Best grade | Attempts | Date passed |
|---|-------|--------|-----------|----------|-------------|
| 1 | Biological control of aphids on vegetable crops | unlocked | — | 0 | — |
| 2 | Biological control of thrips on vegetable crops | locked | — | 0 | — |
| 3 | Biological control of whiteflies on vegetable crops | locked | — | 0 | — |
| 4 | Biological control of tomato leafminer (Tuta absoluta) | locked | — | 0 | — |
| 5 | Biological control of spider mites on vegetable crops | locked | — | 0 | — |
| 6 | Other bioagents: entomopathogenic viruses, bacteria, fungi, nematodes | locked | — | 0 | — |
| 7 | Innovative non-chemical methods & compatibility with bioagents | locked | — | 0 | — |
| 8 | Assessment of biological efficacy of insecticides (lab/field/standards) | locked | — | 0 | — |
| 9 | Selectivity of insecticides: lethal & sublethal effects on beneficials | locked | — | 0 | — |

---

## GRADE LOG
<!-- grader appends one line per attempt: YYYY-MM-DD | Topic N | grade X.XX | PASS/FAIL -->
